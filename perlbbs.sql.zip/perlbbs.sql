-- MySQL dump 10.13  Distrib 5.5.24, for osx10.5 (i386)
--
-- Host: 127.0.0.1    Database: test
-- ------------------------------------------------------
-- Server version	5.5.25a-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `topic`
--

DROP TABLE IF EXISTS `topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `mostRecentThread` int(11) DEFAULT NULL,
  `mostRecentTime` int(11) DEFAULT NULL,
  `deleted` varchar(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `mostRecentThread_idx` (`mostRecentThread`),
  CONSTRAINT `mostRecentThread` FOREIGN KEY (`mostRecentThread`) REFERENCES `thread` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1019 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topic`
--

LOCK TABLES `topic` WRITE;
/*!40000 ALTER TABLE `topic` DISABLE KEYS */;
INSERT INTO `topic` VALUES (1001,'小沢氏と鳩山氏 消費増税批判',NULL,1344072123,'0'),(1002,'青旗3本が白3本に 韓国は激怒',NULL,1344073123,'0'),(1003,'2位指示「選手に申し訳ない」',NULL,1344074150,'0'),(1004,'3億7千万年前の昆虫化石発掘',NULL,1344074231,'0'),(1005,'東電が実質国有化 1兆円注入',NULL,1344074350,'0'),(1006,'小沢氏、政権奪取の決意表明',NULL,1343998637,'0'),(1009,'韓国、竹島近海で訓練計画',NULL,1344345390,'0'),(1010,'脱原発を訴え 国会前でデモ',NULL,1344342001,'0'),(1011,'入れ墨回答拒否6人 懲戒へ',NULL,1344342201,'0'),(1012,'谷亮子議員 リオで復帰に含み',NULL,1344341231,'0'),(1016,'不信任と問責 自民同時提出も',NULL,1344351251,'0'),(1017,'男子サッカー 韓国が英破る',NULL,1344351478,'0'),(1018,'店に自衛隊車両突っ込む 東京',NULL,1344351507,'0');
/*!40000 ALTER TABLE `topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reply`
--

DROP TABLE IF EXISTS `reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `replyUser` varchar(31) DEFAULT NULL,
  `title` varchar(128) DEFAULT NULL,
  `content` varchar(4096) NOT NULL,
  `time` int(11) DEFAULT NULL,
  `attach` varchar(512) DEFAULT NULL,
  `belongThread` int(11) NOT NULL,
  `deleted` varchar(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `replyUser_idx` (`replyUser`),
  KEY `belongThread_idx` (`belongThread`),
  CONSTRAINT `belongThread` FOREIGN KEY (`belongThread`) REFERENCES `thread` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `replyUser` FOREIGN KEY (`replyUser`) REFERENCES `users` (`userID`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reply`
--

LOCK TABLES `reply` WRITE;
/*!40000 ALTER TABLE `reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fromUser` varchar(31) DEFAULT NULL,
  `toUser` varchar(31) NOT NULL,
  `title` varchar(64) DEFAULT NULL,
  `content` varchar(512) NOT NULL,
  `time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `to_idx` (`toUser`),
  CONSTRAINT `to` FOREIGN KEY (`toUser`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `userID` varchar(31) NOT NULL,
  `email` varchar(64) NOT NULL,
  `password` varchar(32) NOT NULL,
  `registrationTime` int(11) DEFAULT NULL,
  `admin` int(11) DEFAULT '0',
  PRIMARY KEY (`userID`),
  UNIQUE KEY `userID_UNIQUE` (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('guest','a@a.com','f3c513f2b332d7bf1e856d47cad36b19',0,0),('kayac','onevcat@gmail.com','f15d293cbb2b17e1a3f4c6dee9415ff0',1344351111,1),('onevcat','onevcat@gmail.com','a6432cb89f8bf994f71fd74d815f7c85',1344351178,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thread`
--

DROP TABLE IF EXISTS `thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thread` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `content` varchar(4096) NOT NULL,
  `time` int(11) NOT NULL,
  `attach` varchar(512) DEFAULT NULL,
  `threadUser` varchar(31) DEFAULT NULL,
  `belongTopic` int(11) NOT NULL,
  `mostRecentReply` int(11) DEFAULT NULL,
  `mostRecentTime` int(11) DEFAULT NULL,
  `deleted` varchar(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `threadUser_idx` (`threadUser`),
  KEY `belongTopic_idx` (`belongTopic`),
  KEY `mostRecentReply_idx` (`mostRecentReply`),
  CONSTRAINT `belongTopic` FOREIGN KEY (`belongTopic`) REFERENCES `topic` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `mostRecentReply` FOREIGN KEY (`mostRecentReply`) REFERENCES `reply` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `threadUser` FOREIGN KEY (`threadUser`) REFERENCES `users` (`userID`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thread`
--

LOCK TABLES `thread` WRITE;
/*!40000 ALTER TABLE `thread` DISABLE KEYS */;
/*!40000 ALTER TABLE `thread` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-08-07 23:43:17
